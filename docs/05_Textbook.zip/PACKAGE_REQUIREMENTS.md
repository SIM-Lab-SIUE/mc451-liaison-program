# Package Requirements & Integration Notes

This textbook repo is intentionally independent from the helper R package (to be hosted in a separate repository). Below are places in the textbook where the helper package will provide conveniences for students and instructors.

Planned helper functions (reference):

- `check_env()` — verify R/Quarto/TinyTeX and required packages; return actionable messages. (Referenced by `templates/assignment_syllabus_contract.qmd`)
- `get_weekly_content(week)` — download lecture notes, datasets, templates. (Used from chapter pages)
- `use_assignment_template(name, dest = ".")` — scaffold assignment files into a student repo. (Referenced in multiple `templates/` files)
- `load_data(path)` — robust CSV importer returning a tidy tibble. (Referenced by `templates/assignment_data_wrangling.qmd`)
- `pilot_icr(coded_df, coder_cols)` — compute percent agreement & Krippendorff's alpha. (Referenced by `templates/assignment_sampling_plan.qmd`)
- `render_portfolio(path, output = c("pdf","html"))` — convenience wrapper for rendering and basic QA. (Referenced by `templates/assignment_final_portfolio.qmd`)

Notes for package maintainers:

- Keep the package lightweight: avoid bundling large datasets or media assets.
- Provide `inst/templates/` in the package for official assignment scaffolds if desired.
- Publish package to GitHub with versioned releases to ensure students can install stable snapshots.
