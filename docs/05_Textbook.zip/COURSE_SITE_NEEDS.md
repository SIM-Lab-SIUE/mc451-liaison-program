# Course Website (Class-Specific) Requirements

This textbook repo is agnostic to any single course offering. The course-specific website (a separate repo) should host the following class-only materials:

- Weekly announcements and calendar
- Syllabus and gradebook integrations (if applicable)
- Assignment submission links / Canvas integration notes
- Private datasets or TA-only resources (not in this public repo)
- Instructor slides, lecture recordings, and supplementary media
- Student-facing schedule, rubrics, and office hours

Integration notes:

- The textbook will link to canonical assignment templates (public). The course site will host class-specific deadlines and example student work.
- Use the helper package to pull canonical content; the course site can provide a small manifest for each semester that maps weeks to content versions.
