# Contributing

Contributions welcome. For the textbook repo, prefer small, focused PRs that update a single chapter or add one assignment template.

Guidelines:

- Use the `main` branch as the canonical release branch; develop on feature branches.
- Keep large datasets out of this repo; host large media as release assets or in the course-site repo.
- For package-related changes (helper utilities), open issues and PRs in the companion `mccoursepack` repository.

See `PACKAGE_REQUIREMENTS.md` for a list of helper functions the textbook references.
