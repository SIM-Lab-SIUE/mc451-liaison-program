# vibes-to-variables

Textbook and course materials for "Research Methods in Mass Media" (MC 451).

This repository contains a Quarto site, teaching materials, and a minimal `mccoursepack` R package used by the course.

Quick start

- Install R, RStudio, and Quarto
- Render the site locally: `quarto render`
- Build and preview with RStudio's Quarto tools

See the `chapters/` folder for chapter templates and `mccoursepack/` for the package skeleton.
