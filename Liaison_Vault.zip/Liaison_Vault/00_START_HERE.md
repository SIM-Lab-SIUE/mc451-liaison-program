# Welcome to your Digital Office

* **00_Inbox**: Quick notes and rough thoughts.
* **01_Journal**: Your weekly field notes.
* **02_Literature**: Notes from Zotero and readings.
* **03_Project**: Your active research work.
* **99_Templates**: Copy these files to start your assignments.

## Task 1: Configure Obsidian Settings

Go to Settings > Files & Links > Default location for new attachments → set to '04_Resources'.
