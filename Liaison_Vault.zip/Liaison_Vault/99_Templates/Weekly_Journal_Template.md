# Week X: [Title Here]

**Date:** [Insert Date]
**Reading:** [Insert Chapter]

## The Reflection

*(Choose one path below and delete the others)*

### Path 1: The Connector

*How does this week's theory specifically apply to the project I am building?*

### Path 2: The Troubleshooter

*What went wrong in the Lab this week, and exactly how did I fix it?*

### Path 3: The Critic

*The author claims X, but does that hold true in my experience/modern media?*

---

**Tags:** #journal #weekX
